import 'dart:math';
import '../core/models.dart';

const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
String noteName(int m) => '${noteNames[m % 12]}${m ~/ 12 - 1}';
bool isBlack(int m) => const {1, 3, 6, 8, 10}.contains(m % 12);

const chordPatterns = <String, List<int>>{
  '': [0, 4, 7], 'm': [0, 3, 7], '7': [0, 4, 7, 10], 'maj7': [0, 4, 7, 11],
  'm7': [0, 3, 7, 10], 'dim': [0, 3, 6], 'aug': [0, 4, 8], 'sus4': [0, 5, 7], 'sus2': [0, 2, 7],
};

/// Detecta o acorde das notas MIDI pressionadas (com inversão -> C/E).
String? detectChord(Iterable<int> midi) {
  if (midi.length < 3) return null;
  final pcs = midi.map((m) => m % 12).toSet();
  final bass = midi.reduce(min) % 12;
  for (final root in [bass, ...pcs.where((p) => p != bass)]) {
    for (final e in chordPatterns.entries) {
      final s = e.value.map((i) => (root + i) % 12).toSet();
      if (s.length == pcs.length && s.containsAll(pcs)) {
        return '${noteNames[root]}${e.key}${root != bass ? '/${noteNames[bass]}' : ''}';
      }
    }
  }
  return null;
}

final chordRe = RegExp(r'^([A-G])([#b]?)(maj7|m7|dim|aug|sus4|sus2|m|7)?(?:/([A-G])([#b]?))?$');

int _pc(String l, String acc) {
  const b = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11};
  return (b[l]! + (acc == '#' ? 1 : acc == 'b' ? -1 : 0) + 12) % 12;
}

/// Converte uma cifra ("Am7", "G/B") num passo de exercício.
Step? chordStep(String sym, {double beats = 4}) {
  final m = chordRe.firstMatch(sym);
  if (m == null) return null;
  final root = _pc(m[1]!, m[2]!);
  final bass = m[4] != null ? _pc(m[4]!, m[5]!) : root;
  final iv = chordPatterns[m[3] ?? '']!;
  return Step(sym, right: [for (final i in iv) 60 + root + i], left: [36 + bass], beats: beats);
}

/// Extrai cifras de um texto: só considera linhas em que TODOS os tokens são cifras.
List<String> extractChords(String text) {
  final out = <String>[];
  for (final line in text.split('\n')) {
    final t = line.trim().split(RegExp(r'[\s|]+')).where((x) => x.isNotEmpty).toList();
    if (t.isNotEmpty && t.every((x) => chordRe.hasMatch(x))) out.addAll(t);
  }
  return out;
}
