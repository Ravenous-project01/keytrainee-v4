import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_midi_command/flutter_midi_command.dart';
import 'package:permission_handler/permission_handler.dart';
import '../audio/synth.dart';

/// Entrada única de notas: teclado virtual + USB MIDI + Bluetooth MIDI.
class MidiService extends ChangeNotifier {
  final _midi = MidiCommand();
  final _on = StreamController<int>.broadcast();
  final _off = StreamController<int>.broadcast();
  Stream<int> get onNoteOn => _on.stream;
  Stream<int> get onNoteOff => _off.stream;
  final Set<int> pressed = {};
  List<MidiDevice> devices = [];
  MidiDevice? connected;
  String status = 'Nenhum dispositivo conectado';
  bool externalSound = false, scanning = false;
  StreamSubscription? _data, _setup;

  MidiService() {
    _setup = _midi.onMidiSetupChanged?.listen((_) => scan());
  }

  void setExternalSound(bool v) { externalSound = v; notifyListeners(); }

  void press(int n, {bool external = false}) {
    pressed.add(n);
    if (!external || externalSound) Synth.note(n);
    _on.add(n);
    notifyListeners();
  }

  void release(int n) {
    pressed.remove(n);
    _off.add(n);
    notifyListeners();
  }

  Future<void> scan() async {
    devices = (await _midi.devices) ?? [];
    notifyListeners();
  }

  Future<void> scanBluetooth() async {
    await [Permission.bluetoothScan, Permission.bluetoothConnect, Permission.locationWhenInUse].request();
    try {
      await _midi.startBluetoothCentral();
      await _midi.waitUntilBluetoothIsInitialized();
      await _midi.startScanningForBluetoothDevices();
      scanning = true;
      status = 'Procurando dispositivos Bluetooth…';
    } catch (e) {
      status = 'Bluetooth indisponível: $e';
    }
    notifyListeners();
    Future.delayed(const Duration(seconds: 5), () async {
      _midi.stopScanningForBluetoothDevices();
      scanning = false;
      await scan();
    });
  }

  Future<void> connect(MidiDevice d) async {
    try {
      await _midi.connectToDevice(d);
      connected = d;
      _data?.cancel();
      _data = _midi.onMidiDataReceived?.listen(_parse);
      status = 'Conectado: ${d.name}';
    } catch (e) {
      status = 'Falha ao conectar: $e';
    }
    notifyListeners();
  }

  void disconnect() {
    if (connected != null) _midi.disconnectDevice(connected!);
    _data?.cancel();
    connected = null;
    status = 'Nenhum dispositivo conectado';
    notifyListeners();
  }

  void _parse(MidiPacket p) {
    final d = p.data;
    var i = 0;
    while (i < d.length) {
      final s = d[i];
      if (s & 0x80 == 0) { i++; continue; }
      final t = s & 0xF0;
      if (t == 0xC0 || t == 0xD0) { i += 2; continue; }
      if (i + 2 >= d.length) break;
      if (t == 0x90 && d[i + 2] > 0) {
        press(d[i + 1], external: true);
      } else if (t == 0x80 || t == 0x90) {
        release(d[i + 1]);
      }
      i += 3;
    }
  }

  @override
  void dispose() {
    _data?.cancel();
    _setup?.cancel();
    super.dispose();
  }
}
