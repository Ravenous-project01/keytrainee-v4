import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ai/teacher.dart';
import '../progress/store.dart';
import 'library_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    final plan = Teacher.dailyPlan(s);
    return Scaffold(
      appBar: AppBar(title: const Text('KeyTrainer'), actions: [
        IconButton(icon: const Icon(Icons.library_music), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LibraryScreen()))),
        IconButton(icon: const Icon(Icons.settings), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
      ]),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Nível ${s.level} · ${s.xp} XP · 🔥 ${s.streak} dia(s)', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text('Meta de hoje: ${s.todayCount}/${s.dailyGoal} sessões'),
              LinearProgressIndicator(value: (s.todayCount / s.dailyGoal).clamp(0.0, 1.0)),
            ]),
          ),
        ),
        Text('Plano de hoje', style: Theme.of(context).textTheme.titleMedium),
        for (final p in plan)
          Card(
            child: ListTile(
              title: Text(p.title),
              subtitle: Text('${p.desc} · ${p.bpm} BPM'),
              trailing: FilledButton(onPressed: () => s.select(p.exercise, bpm: p.bpm), child: const Text('Iniciar')),
            ),
          ),
        const SizedBox(height: 8),
        Text('Recomendações do professor', style: Theme.of(context).textTheme.titleMedium),
        for (final r in Teacher.recommendations(s)) ListTile(dense: true, leading: const Icon(Icons.lightbulb_outline), title: Text(r)),
      ]),
    );
  }
}
