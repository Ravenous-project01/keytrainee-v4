import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ai/teacher.dart';
import '../music/theory.dart';
import '../progress/store.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    final last = s.sessions.reversed.take(14).toList().reversed.toList();
    final weak = Teacher.weakNotes(s);
    return Scaffold(
      appBar: AppBar(title: const Text('Evolução')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Text('Precisão das últimas sessões', style: Theme.of(context).textTheme.titleMedium),
        SizedBox(
          height: 110,
          child: last.isEmpty
              ? const Center(child: Text('Sem sessões ainda'))
              : Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  for (final r in last)
                    Expanded(child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      height: 100 * r.accuracy.clamp(0.03, 1.0),
                      color: r.accuracy >= 0.9 ? Colors.green : r.accuracy >= 0.7 ? Colors.orange : Colors.red,
                    )),
                ]),
        ),
        const SizedBox(height: 12),
        Text('Pontos fracos', style: Theme.of(context).textTheme.titleMedium),
        if (weak.isEmpty) const Text('Nada por enquanto.'),
        for (final w in weak) ListTile(dense: true, title: Text('${noteName(w.key)} — ${w.value} erros')),
        if (weak.isNotEmpty)
          FilledButton.tonal(
            onPressed: () {
              final g = Teacher.fromErrors(s);
              if (g != null) s.select(g, bpm: g.bpm);
            },
            child: const Text('Gerar exercício dos meus erros'),
          ),
        const SizedBox(height: 12),
        Text('Meta diária: ${s.dailyGoal} sessões', style: Theme.of(context).textTheme.titleMedium),
        Slider(value: s.dailyGoal.toDouble(), min: 1, max: 10, divisions: 9, label: '${s.dailyGoal}', onChanged: (v) => s.setGoal(v.round())),
        Text('Conquistas', style: Theme.of(context).textTheme.titleMedium),
        if (s.achievements.isEmpty) const Text('Treine para desbloquear.'),
        for (final a in s.achievements) ListTile(dense: true, title: Text(a)),
        if (s.sessions.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text('Última sessão — o que melhorar', style: Theme.of(context).textTheme.titleMedium),
          for (final t in Teacher.explain(s.sessions.last)) ListTile(dense: true, leading: const Icon(Icons.school), title: Text(t)),
        ],
        const SizedBox(height: 12),
        Text('Histórico', style: Theme.of(context).textTheme.titleMedium),
        for (final r in s.sessions.reversed.take(30))
          ListTile(
            dense: true,
            title: Text(r.title),
            subtitle: Text('${r.date.day}/${r.date.month} · ${r.bpm} BPM · ${r.seconds}s'),
            trailing: Text('${(r.accuracy * 100).round()}%'),
          ),
      ]),
    );
  }
}
