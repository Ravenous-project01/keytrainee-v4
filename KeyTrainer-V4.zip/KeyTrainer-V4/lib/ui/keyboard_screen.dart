import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../midi/midi_service.dart';
import '../music/theory.dart';
import '../training/metronome.dart';
import 'mic_card.dart';
import 'piano.dart';

class KeyboardScreen extends StatelessWidget {
  const KeyboardScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final midi = context.watch<MidiService>();
    final met = context.watch<Metronome>();
    final notes = midi.pressed.toList()..sort();
    final chord = detectChord(notes);
    return Scaffold(
      appBar: AppBar(title: const Text('Teclado livre')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Text(notes.isEmpty ? 'Toque uma tecla' : notes.map(noteName).join('  '), style: Theme.of(context).textTheme.titleLarge),
        Text(chord == null ? ' ' : 'Acorde: $chord', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        PianoKeyboard(pressed: midi.pressed, onDown: midi.press, onUp: midi.release),
        const SizedBox(height: 12),
        const MicCard(),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              Row(children: [
                const Icon(Icons.timer),
                const SizedBox(width: 8),
                Text('Metrônomo  ${met.bpm} BPM', style: Theme.of(context).textTheme.titleSmall),
                const Spacer(),
                Text(met.running ? '● ${met.beat % met.beatsPerBar + 1}' : ''),
                IconButton(
                  icon: Icon(met.running ? Icons.stop : Icons.play_arrow),
                  onPressed: () => met.running ? met.stop() : met.start(),
                ),
              ]),
              Slider(value: met.bpm.toDouble(), min: 40, max: 200, divisions: 160, onChanged: (v) => met.setBpm(v.round())),
            ]),
          ),
        ),
      ]),
    );
  }
}
