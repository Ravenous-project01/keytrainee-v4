import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../audio/mic_service.dart';
import '../audio/synth.dart';

/// Controle da análise de áudio pelo microfone do aparelho.
class MicCard extends StatelessWidget {
  const MicCard({super.key});
  @override
  Widget build(BuildContext context) {
    final mic = context.watch<MicService>();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.mic),
            const SizedBox(width: 8),
            Expanded(child: Text('Microfone (piano acústico/teclado)', style: Theme.of(context).textTheme.titleSmall)),
            Switch(
              value: mic.listening,
              onChanged: (v) async {
                if (v) {
                  Synth.enabled = false; // evita o app "ouvir a si mesmo"
                  await mic.start();
                } else {
                  await mic.stop();
                  Synth.enabled = true;
                }
              },
            ),
          ]),
          Text(mic.status),
          if (mic.chord != null) Text('Acorde: ${mic.chord}', style: const TextStyle(fontWeight: FontWeight.bold)),
          if (mic.listening) ...[
            LinearProgressIndicator(value: (mic.level * 8).clamp(0.0, 1.0)),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Nota única')),
                ButtonSegment(value: true, label: Text('Acordes (beta)')),
              ],
              selected: {mic.chordMode},
              onSelectionChanged: (s) => mic.setChordMode(s.first),
            ),
            Row(children: [
              const Text('Sensibilidade'),
              Expanded(
                child: Slider(
                  value: (0.05 - mic.sensitivity).clamp(0.002, 0.048),
                  min: 0.002, max: 0.048,
                  onChanged: (v) => mic.setSensitivity(0.05 - v),
                ),
              ),
            ]),
            const Text('Dica: com o microfone, o som do app é desligado e a oitava é livre (conta só a nota). Use ambiente silencioso e o metrônomo em fones.',
                style: TextStyle(fontSize: 12)),
          ],
        ]),
      ),
    );
  }
}
