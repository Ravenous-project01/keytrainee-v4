import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../midi/midi_service.dart';
import '../progress/store.dart';
import 'mic_card.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final midi = context.watch<MidiService>();
    final s = context.watch<AppStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Text('MIDI', style: Theme.of(context).textTheme.titleMedium),
        Text(midi.status),
        Wrap(spacing: 8, children: [
          OutlinedButton.icon(onPressed: midi.scan, icon: const Icon(Icons.usb), label: const Text('Buscar USB')),
          OutlinedButton.icon(onPressed: midi.scanning ? null : midi.scanBluetooth, icon: const Icon(Icons.bluetooth), label: const Text('Buscar Bluetooth')),
          if (midi.connected != null) TextButton(onPressed: midi.disconnect, child: const Text('Desconectar')),
        ]),
        for (final d in midi.devices)
          ListTile(
            leading: Icon(d.type == 'BLE' ? Icons.bluetooth : Icons.piano),
            title: Text(d.name),
            subtitle: Text(d.type),
            trailing: FilledButton(onPressed: () => midi.connect(d), child: const Text('Conectar')),
          ),
        SwitchListTile(
          title: const Text('Tocar som do app para teclado MIDI'),
          subtitle: const Text('Desligado: use o som do próprio teclado.'),
          value: midi.externalSound,
          onChanged: midi.setExternalSound,
        ),
        const Divider(),
        const MicCard(),
        const Divider(),
        ListTile(
          title: Text('BPM padrão: ${s.defaultBpm}'),
          subtitle: Slider(value: s.defaultBpm.toDouble(), min: 40, max: 160, divisions: 120, onChanged: (v) => s.setDefaultBpm(v.round())),
        ),
      ]),
    );
  }
}
