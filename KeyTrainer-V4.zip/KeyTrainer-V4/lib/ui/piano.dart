import 'package:flutter/material.dart';
import '../music/theory.dart';

class PianoKeyboard extends StatefulWidget {
  final int low, high;
  final Set<int> expected, pressed, wrong;
  final void Function(int) onDown, onUp;
  const PianoKeyboard({
    super.key, this.low = 36, this.high = 84, this.expected = const {},
    this.pressed = const {}, this.wrong = const {}, required this.onDown, required this.onUp,
  });
  @override
  State<PianoKeyboard> createState() => _PianoKeyboardState();
}

class _PianoKeyboardState extends State<PianoKeyboard> {
  static const kw = 46.0, h = 170.0;
  late final ScrollController sc;
  @override
  void initState() {
    super.initState();
    final whites = [for (var m = widget.low; m < 60; m++) if (!isBlack(m)) m].length;
    sc = ScrollController(initialScrollOffset: (whites - 1) * kw);
  }
  @override
  void dispose() { sc.dispose(); super.dispose(); }

  Widget _key(int m, bool black) {
    final w = widget;
    Color c = black ? Colors.black87 : Colors.white;
    if (w.expected.contains(m)) c = Colors.lightBlueAccent;
    if (w.pressed.contains(m)) c = Colors.greenAccent.shade400;
    if (w.wrong.contains(m)) c = Colors.redAccent;
    return Listener(
      onPointerDown: (_) => w.onDown(m),
      onPointerUp: (_) => w.onUp(m),
      onPointerCancel: (_) => w.onUp(m),
      child: Container(
        decoration: BoxDecoration(color: c, border: Border.all(color: Colors.black54), borderRadius: const BorderRadius.vertical(bottom: Radius.circular(6))),
        alignment: Alignment.bottomCenter,
        padding: const EdgeInsets.only(bottom: 4),
        child: m % 12 == 0 ? Text(noteName(m), style: TextStyle(fontSize: 10, color: black ? Colors.white : Colors.black54)) : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final whites = [for (var m = widget.low; m <= widget.high; m++) if (!isBlack(m)) m];
    return SizedBox(
      height: h,
      child: SingleChildScrollView(
        controller: sc,
        scrollDirection: Axis.horizontal,
        child: SizedBox(
          width: whites.length * kw, height: h,
          child: Stack(children: [
            for (var i = 0; i < whites.length; i++)
              Positioned(left: i * kw, width: kw, top: 0, bottom: 0, child: _key(whites[i], false)),
            for (var i = 0; i < whites.length; i++)
              if (whites[i] + 1 <= widget.high && isBlack(whites[i] + 1))
                Positioned(left: i * kw + kw * 0.65, width: kw * 0.7, top: 0, height: h * 0.6, child: _key(whites[i] + 1, true)),
          ]),
        ),
      ),
    );
  }
}
