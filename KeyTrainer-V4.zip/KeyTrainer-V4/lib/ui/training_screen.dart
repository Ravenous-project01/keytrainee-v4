import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ai/teacher.dart';
import '../midi/midi_service.dart';
import '../music/theory.dart';
import '../pdf/pdf_view.dart';
import '../progress/store.dart';
import '../audio/mic_service.dart';
import '../training/engine.dart';
import '../training/metronome.dart';
import 'library_screen.dart';
import 'mic_card.dart';
import 'piano.dart';

class TrainingScreen extends StatefulWidget {
  const TrainingScreen({super.key});
  @override
  State<TrainingScreen> createState() => _TrainingScreenState();
}

class _TrainingScreenState extends State<TrainingScreen> {
  late final TrainingEngine eng;
  String? _lastId;
  bool _dialog = false, useMet = true;

  @override
  void initState() {
    super.initState();
    eng = TrainingEngine(context.read<MidiService>())..addListener(_onEng);
  }

  @override
  void dispose() {
    eng.removeListener(_onEng);
    eng.dispose();
    super.dispose();
  }

  void _onEng() {
    final r = eng.result;
    if (r == null || _dialog) return;
    _dialog = true;
    eng.result = null;
    final store = context.read<AppStore>();
    context.read<Metronome>().stop();
    store.addSession(r).then((_) {
      if (!mounted) return;
      final next = Teacher.suggestBpm(store, r.exerciseId, r.bpm);
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('Precisão ${(r.accuracy * 100).round()}%'),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Acertos ${r.hits} · Erros ${r.errors} · Faltas ${r.misses} · ${r.seconds}s'),
            if (r.avgLateMs > 0) Text('Atraso médio: ${r.avgLateMs.round()} ms'),
            const SizedBox(height: 8),
            for (final t in Teacher.explain(r)) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('• $t')),
            const SizedBox(height: 8),
            Text('Próximo BPM sugerido: $next', style: const TextStyle(fontWeight: FontWeight.bold)),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      ).then((_) => _dialog = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<AppStore>();
    final midi = context.watch<MidiService>();
    final met = context.watch<Metronome>();
    final mic = context.watch<MicService>();
    final ex = store.selected;
    eng.octaveFree = mic.listening;
    if (ex != null && ex.id != _lastId) {
      _lastId = ex.id;
      WidgetsBinding.instance.addPostFrameCallback((_) => eng.load(ex, store.selectedBpm ?? ex.bpm));
    }
    return Scaffold(
      appBar: AppBar(title: Text(ex?.title ?? 'Treino')),
      body: ListenableBuilder(
        listenable: eng,
        builder: (context, _) => ListView(padding: const EdgeInsets.all(12), children: [
          OutlinedButton.icon(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LibraryScreen())),
            icon: const Icon(Icons.library_music),
            label: Text(ex == null ? 'Escolher exercício' : 'Trocar exercício'),
          ),
          if (ex != null) ...[
            if (ex.pdfPath != null) SizedBox(height: 200, child: PdfPageView(path: ex.pdfPath!, page: ex.page)),
            Center(child: Text(eng.running ? eng.label : '—', style: const TextStyle(fontSize: 44, fontWeight: FontWeight.bold))),
            Center(child: Text(eng.running ? eng.required.map(noteName).join('  ') : (eng.info ?? 'Pronto'))),
            LinearProgressIndicator(value: eng.progress),
            const SizedBox(height: 4),
            Text('✔ ${eng.hits}   ✖ ${eng.errors}   ⏱ ${eng.misses}${eng.loop ? '   ↻ ${eng.loops}' : ''}'),
            const SizedBox(height: 8),
            PianoKeyboard(
              expected: eng.running ? eng.required.toSet() : {},
              pressed: midi.pressed, wrong: eng.wrong,
              onDown: midi.press, onUp: midi.release,
            ),
            const SizedBox(height: 8),
            SegmentedButton<Mode>(
              segments: const [
                ButtonSegment(value: Mode.wait, label: Text('Esperar nota')),
                ButtonSegment(value: Mode.timed, label: Text('No tempo')),
              ],
              selected: {eng.mode},
              onSelectionChanged: eng.running ? null : (s) => eng.setMode(s.first),
            ),
            const SizedBox(height: 8),
            SegmentedButton<Hand>(
              segments: const [
                ButtonSegment(value: Hand.right, label: Text('Direita')),
                ButtonSegment(value: Hand.left, label: Text('Esquerda')),
                ButtonSegment(value: Hand.both, label: Text('Duas')),
              ],
              selected: {eng.hand},
              onSelectionChanged: eng.running ? null : (s) => eng.setHand(s.first),
            ),
            Text('BPM ${eng.bpm}${eng.speed < 1 ? '  (efetivo ${(eng.bpm * eng.speed).round()})' : ''}'),
            Slider(value: eng.bpm.toDouble().clamp(40, 200), min: 40, max: 200, divisions: 160, onChanged: eng.running ? null : (v) => eng.setBpm(v.round())),
            SwitchListTile(dense: true, title: const Text('Modo lento (50%)'), value: eng.speed < 1, onChanged: eng.running ? null : (v) => eng.setSpeed(v ? 0.5 : 1)),
            SwitchListTile(dense: true, title: const Text('Metrônomo'), value: useMet, onChanged: (v) => setState(() => useMet = v)),
            SwitchListTile(dense: true, title: const Text('Loop de compassos'), value: eng.loop, onChanged: eng.running ? null : eng.setLoop),
            if (eng.loop)
              Row(children: [
                const Text('Do '),
                DropdownButton<int>(
                  value: eng.loopFrom.clamp(1, eng.totalBars),
                  items: [for (var i = 1; i <= eng.totalBars; i++) DropdownMenuItem(value: i, child: Text('$i'))],
                  onChanged: eng.running ? null : (v) => eng.setLoopRange(v!, eng.loopTo),
                ),
                const Text('  ao '),
                DropdownButton<int>(
                  value: eng.loopTo.clamp(1, eng.totalBars),
                  items: [for (var i = 1; i <= eng.totalBars; i++) DropdownMenuItem(value: i, child: Text('$i'))],
                  onChanged: eng.running ? null : (v) => eng.setLoopRange(eng.loopFrom, v!),
                ),
              ]),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: () {
                if (eng.running) {
                  eng.stop();
                  met.stop();
                } else {
                  if (useMet || eng.mode == Mode.timed) {
                    met.bpm = (eng.bpm * eng.speed).round();
                    met.start();
                  }
                  eng.start();
                }
              },
              icon: Icon(eng.running ? Icons.stop : Icons.play_arrow),
              label: Text(eng.running ? 'Parar' : 'Começar'),
            ),
            const SizedBox(height: 8),
            const MicCard(),
            ExpansionTile(title: const Text('Análise da música'), children: [Padding(padding: const EdgeInsets.all(12), child: Text(Teacher.analyze(ex)))]),
          ],
        ]),
      ),
    );
  }
}
