import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ai/teacher.dart';
import '../progress/store.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('Biblioteca')),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.picture_as_pdf),
        label: const Text('Importar PDF / cifra'),
        onPressed: () { Navigator.pop(context); s.go(3); },
      ),
      body: ListView(children: [
        for (final e in s.all)
          Builder(builder: (_) {
            final l = s.sessions.where((x) => x.exerciseId == e.id).toList();
            final best = l.isEmpty ? null : l.map((x) => x.accuracy).reduce((a, b) => a > b ? a : b);
            return ListTile(
              leading: Icon(e.pdfPath != null ? Icons.picture_as_pdf : e.user ? Icons.library_music : Icons.piano),
              title: Text(e.title),
              subtitle: Text('${e.level} · ${e.steps.length} passos · ${e.bpm} BPM'
                  '${best == null ? '' : ' · melhor ${(best * 100).round()}%'}'),
              trailing: e.user
                  ? IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => s.removeUser(e.id))
                  : null,
              onTap: () { Navigator.pop(context); s.select(e, bpm: Teacher.suggestBpm(s, e.id, e.bpm)); },
            );
          }),
        const SizedBox(height: 80),
      ]),
    );
  }
}
