import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import '../core/models.dart';
import '../music/theory.dart';
import '../pdf/ocr.dart';
import '../pdf/pdf_view.dart';
import '../progress/store.dart';

class PdfScreen extends StatefulWidget {
  const PdfScreen({super.key});
  @override
  State<PdfScreen> createState() => _PdfScreenState();
}

class _PdfScreenState extends State<PdfScreen> {
  String? path;
  int page = 1;
  bool busy = false;
  final title = TextEditingController(text: 'Minha cifra');
  final chords = TextEditingController();

  Future<void> _open() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    final src = r?.files.single.path;
    if (src == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dst = '${dir.path}/${src.split('/').last}';
    await File(src).copy(dst);
    setState(() { path = dst; page = 1; title.text = src.split('/').last.replaceAll('.pdf', ''); });
  }

  Future<void> _ocr() async {
    setState(() => busy = true);
    try {
      final txt = await ocrPage(path!, page);
      final found = extractChords(txt);
      chords.text = found.join(' ');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(found.isEmpty ? 'Nenhuma cifra reconhecida. Digite abaixo.' : '${found.length} cifras reconhecidas. Confira e corrija.')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Falha no OCR: $e')));
    }
    if (mounted) setState(() => busy = false);
  }

  Exercise? _build() {
    final syms = chords.text.trim().split(RegExp(r'[\s|]+')).where((x) => x.isNotEmpty).toList();
    final steps = [for (final s in syms) if (chordStep(s) != null) chordStep(s)!];
    if (steps.isEmpty) return null;
    return Exercise('cifra-${DateTime.now().millisecondsSinceEpoch}', title.text, 'Cifra',
        context.read<AppStore>().defaultBpm, steps, pdfPath: path, page: page, user: true);
  }

  @override
  Widget build(BuildContext context) {
    final store = context.read<AppStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('PDF e cifras'), actions: [
        IconButton(icon: const Icon(Icons.folder_open), onPressed: _open),
      ]),
      body: Column(children: [
        if (path != null)
          SizedBox(height: 280, child: PdfPageView(path: path!, page: page, onPage: (p) => page = p))
        else
          const Padding(padding: EdgeInsets.all(24), child: Text('Abra um PDF de cifra ou partitura (ícone de pasta), ou digite as cifras abaixo.')),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(12), children: [
            if (path != null)
              FilledButton.tonalIcon(
                onPressed: busy ? null : _ocr,
                icon: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.document_scanner),
                label: const Text('Ler cifras desta página (OCR)'),
              ),
            const SizedBox(height: 8),
            TextField(controller: title, decoration: const InputDecoration(labelText: 'Nome')),
            TextField(
              controller: chords, maxLines: 4,
              decoration: const InputDecoration(labelText: 'Cifras (ex.: C G Am F  Dm7 G7 Cmaj7)', alignLabelWithHint: true),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: OutlinedButton(
                onPressed: () async {
                  final e = _build();
                  if (e == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nenhuma cifra válida.'))); return; }
                  await store.addUser(e);
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Salvo na biblioteca.')));
                },
                child: const Text('Salvar'),
              )),
              const SizedBox(width: 8),
              Expanded(child: FilledButton(
                onPressed: () async {
                  final e = _build();
                  if (e == null) return;
                  await store.addUser(e);
                  store.select(e);
                },
                child: const Text('Treinar agora'),
              )),
            ]),
          ]),
        ),
      ]),
    );
  }
}
