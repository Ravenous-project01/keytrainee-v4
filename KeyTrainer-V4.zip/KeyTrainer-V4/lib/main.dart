import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'audio/mic_service.dart';
import 'midi/midi_service.dart';
import 'progress/store.dart';
import 'training/metronome.dart';
import 'ui/home_screen.dart';
import 'ui/keyboard_screen.dart';
import 'ui/pdf_screen.dart';
import 'ui/progress_screen.dart';
import 'ui/training_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  final midi = MidiService();
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: store),
      ChangeNotifierProvider.value(value: midi),
      ChangeNotifierProvider(create: (_) => Metronome()),
      ChangeNotifierProvider(create: (_) => MicService(midi)),
    ],
    child: MaterialApp(
      title: 'KeyTrainer',
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      darkTheme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true, brightness: Brightness.dark),
      home: const Shell(),
    ),
  ));
}

class Shell extends StatelessWidget {
  const Shell({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    return Scaffold(
      body: IndexedStack(index: s.tab, children: const [
        HomeScreen(), KeyboardScreen(), TrainingScreen(), PdfScreen(), ProgressScreen(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: s.tab,
        onDestinationSelected: s.go,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.piano), label: 'Teclado'),
          NavigationDestination(icon: Icon(Icons.school), label: 'Treino'),
          NavigationDestination(icon: Icon(Icons.picture_as_pdf), label: 'PDF'),
          NavigationDestination(icon: Icon(Icons.show_chart), label: 'Evolução'),
        ],
      ),
    );
  }
}
