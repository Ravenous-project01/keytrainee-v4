import 'dart:io';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdfx/pdfx.dart';

/// Renderiza a página do PDF e roda OCR (ML Kit, no aparelho) para ler cifras.
Future<String> ocrPage(String pdfPath, int page) async {
  final doc = await PdfDocument.openFile(pdfPath);
  final pg = await doc.getPage(page);
  final img = await pg.render(
      width: pg.width * 2, height: pg.height * 2, format: PdfPageImageFormat.png, backgroundColor: '#FFFFFF');
  await pg.close();
  await doc.close();
  final dir = await getTemporaryDirectory();
  final f = File('${dir.path}/ocr_$page.png');
  await f.writeAsBytes(img!.bytes);
  final rec = TextRecognizer(script: TextRecognitionScript.latin);
  try {
    return (await rec.processImage(InputImage.fromFile(f))).text;
  } finally {
    rec.close();
  }
}
