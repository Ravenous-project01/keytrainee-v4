import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';

class PdfPageView extends StatefulWidget {
  final String path;
  final int page;
  final ValueChanged<int>? onPage;
  const PdfPageView({super.key, required this.path, this.page = 1, this.onPage});
  @override
  State<PdfPageView> createState() => _PdfPageViewState();
}

class _PdfPageViewState extends State<PdfPageView> {
  late PdfController c;
  PdfController _mk() => PdfController(document: PdfDocument.openFile(widget.path), initialPage: widget.page);
  @override
  void initState() { super.initState(); c = _mk(); }
  @override
  void didUpdateWidget(PdfPageView o) {
    super.didUpdateWidget(o);
    if (o.path != widget.path) {
      c.dispose();
      c = _mk();
    } else if (o.page != widget.page) {
      c.jumpToPage(widget.page);
    }
  }
  @override
  void dispose() { c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) =>
      PdfView(controller: c, onPageChanged: widget.onPage, scrollDirection: Axis.horizontal);
}
