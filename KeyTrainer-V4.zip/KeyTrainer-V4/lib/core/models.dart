class Step {
  final String label;
  final List<int> right, left;
  final double beats;
  const Step(this.label, {this.right = const [], this.left = const [], this.beats = 1});
  Map<String, dynamic> toJson() => {'l': label, 'r': right, 'x': left, 'b': beats};
  factory Step.fromJson(Map j) => Step(j['l'] ?? '',
      right: List<int>.from(j['r'] ?? []),
      left: List<int>.from(j['x'] ?? []),
      beats: (j['b'] ?? 1).toDouble());
}

class Exercise {
  final String id, title, level;
  final int bpm;
  final List<Step> steps;
  final String? pdfPath;
  final int page;
  final bool user;
  const Exercise(this.id, this.title, this.level, this.bpm, this.steps,
      {this.pdfPath, this.page = 1, this.user = false});
  Map<String, dynamic> toJson() => {
        'id': id, 'title': title, 'level': level, 'bpm': bpm,
        'steps': steps.map((s) => s.toJson()).toList(),
        'pdf': pdfPath, 'page': page,
      };
  factory Exercise.fromJson(Map j, {bool user = false}) => Exercise(
        j['id'], j['title'], j['level'] ?? '', j['bpm'] ?? 80,
        (j['steps'] as List).map((s) => Step.fromJson(s)).toList(),
        pdfPath: j['pdf'], page: j['page'] ?? 1, user: user);
}

class SessionResult {
  final String exerciseId, title;
  final DateTime date;
  final int bpm, hits, errors, misses, seconds;
  final double avgLateMs;
  final Map<String, int> errs; // "esperado>tocado" (tocado = -1 -> faltou)
  const SessionResult({
    required this.exerciseId, required this.title, required this.date,
    required this.bpm, required this.hits, required this.errors,
    required this.misses, required this.seconds, required this.avgLateMs,
    required this.errs,
  });
  double get accuracy {
    final t = hits + errors + misses;
    return t == 0 ? 0 : hits / t;
  }

  Map<String, dynamic> toJson() => {
        'id': exerciseId, 't': title, 'd': date.toIso8601String(), 'bpm': bpm,
        'h': hits, 'e': errors, 'm': misses, 's': seconds, 'late': avgLateMs, 'errs': errs,
      };
  factory SessionResult.fromJson(Map j) => SessionResult(
        exerciseId: j['id'], title: j['t'], date: DateTime.parse(j['d']),
        bpm: j['bpm'], hits: j['h'], errors: j['e'], misses: j['m'],
        seconds: j['s'], avgLateMs: (j['late'] ?? 0).toDouble(),
        errs: Map<String, int>.from(j['errs'] ?? {}));
}
