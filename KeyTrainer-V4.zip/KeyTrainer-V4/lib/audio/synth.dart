import 'dart:math';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';

/// Sintetizador simples: gera WAV em memória (sem arquivos de som).
class Synth {
  static const _sr = 22050;
  static final _cache = <String, Uint8List>{};
  static final _players = List.generate(10, (_) => AudioPlayer());
  static int _i = 0;
  static bool enabled = true;

  static Uint8List _wav(double f, double dur, double decay) {
    final n = (_sr * dur).round();
    final bd = ByteData(44 + n * 2);
    void s(int o, String t) {
      for (var i = 0; i < 4; i++) {
        bd.setUint8(o + i, t.codeUnitAt(i));
      }
    }
    s(0, 'RIFF'); bd.setUint32(4, 36 + n * 2, Endian.little); s(8, 'WAVE'); s(12, 'fmt ');
    bd.setUint32(16, 16, Endian.little); bd.setUint16(20, 1, Endian.little);
    bd.setUint16(22, 1, Endian.little); bd.setUint32(24, _sr, Endian.little);
    bd.setUint32(28, _sr * 2, Endian.little); bd.setUint16(32, 2, Endian.little);
    bd.setUint16(34, 16, Endian.little); s(36, 'data'); bd.setUint32(40, n * 2, Endian.little);
    for (var i = 0; i < n; i++) {
      final t = i / _sr;
      final env = min(1.0, t / 0.005) * exp(-decay * t);
      final v = (sin(2 * pi * f * t) + 0.4 * sin(4 * pi * f * t) + 0.2 * sin(6 * pi * f * t)) * env * 0.25;
      bd.setInt16(44 + i * 2, (v * 32767).round().clamp(-32768, 32767), Endian.little);
    }
    return bd.buffer.asUint8List();
  }

  static void note(int m) {
    if (!enabled) return;
    _play(_cache.putIfAbsent('n$m', () => _wav(440 * pow(2, (m - 69) / 12).toDouble(), 1.2, 3)));
  }

  static void click(bool accent) =>
      _play(_cache.putIfAbsent(accent ? 'ca' : 'cn', () => _wav(accent ? 1600 : 1100, 0.05, 60)));

  static void _play(Uint8List b) {
    final p = _players[_i++ % _players.length];
    p.play(BytesSource(b));
  }
}
