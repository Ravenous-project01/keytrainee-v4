import 'dart:math';
import 'dart:typed_data';

/// Frequência fundamental (YIN) de uma nota única. Retorna null se não houver tom claro.
double? yinPitch(Float64List x, int sr, {double thr = 0.15}) {
  final half = x.length ~/ 2;
  final minTau = (sr / 1500).round();
  final maxTau = min(half - 1, (sr / 60).round());
  final cm = Float64List(maxTau + 2);
  cm[0] = 1;
  var run = 0.0;
  for (var tau = 1; tau <= maxTau; tau++) {
    var sum = 0.0;
    for (var j = 0; j < half; j++) {
      final d = x[j] - x[j + tau];
      sum += d * d;
    }
    run += sum;
    cm[tau] = run == 0 ? 1 : sum * tau / run;
  }
  var tau = -1;
  for (var t = minTau; t < maxTau; t++) {
    if (cm[t] < thr) {
      while (t + 1 < maxTau && cm[t + 1] < cm[t]) { t++; }
      tau = t;
      break;
    }
  }
  if (tau < 0) return null;
  var better = tau.toDouble();
  if (tau > 1 && tau < maxTau) {
    final a = cm[tau - 1], b = cm[tau], c = cm[tau + 1];
    final den = 2 * (2 * b - c - a);
    if (den != 0) better = tau + (c - a) / den;
  }
  return sr / better;
}

int freqToMidi(double f) => (69 + 12 * (log(f / 440) / ln2)).round();

/// Multi-pitch aproximado (acordes) via Goertzel por nota MIDI + supressão de harmônicos.
/// Experimental: funciona melhor com piano acústico/teclado em ambiente silencioso.
Set<int> multiPitch(Float64List x, int sr, {int lo = 36, int hi = 96}) {
  final n = x.length;
  final w = Float64List(n);
  for (var i = 0; i < n; i++) {
    w[i] = x[i] * (0.5 - 0.5 * cos(2 * pi * i / (n - 1)));
  }
  final mags = <int, double>{};
  for (var m = lo; m <= hi; m++) {
    final f = 440 * pow(2, (m - 69) / 12);
    final coeff = 2 * cos(2 * pi * f / sr);
    var s1 = 0.0, s2 = 0.0;
    for (var i = 0; i < n; i++) {
      final s0 = w[i] + coeff * s1 - s2;
      s2 = s1;
      s1 = s0;
    }
    mags[m] = s1 * s1 + s2 * s2 - coeff * s1 * s2;
  }
  final mx = mags.values.reduce(max);
  if (mx <= 0) return {};
  final cand = <int>[];
  for (var m = lo; m <= hi; m++) {
    final v = mags[m]!;
    if (v < mx * 0.12) continue;
    if (v >= (mags[m - 1] ?? 0) && v >= (mags[m + 1] ?? 0)) cand.add(m);
  }
  final out = <int>{};
  for (final c in cand) {
    var harmonic = false;
    for (final b in out) {
      if (const {12, 19, 24, 28}.contains(c - b) && mags[c]! < mags[b]! * 0.8) harmonic = true;
    }
    if (!harmonic) out.add(c);
  }
  return out.length > 6 ? (out.toList()..sort((a, b) => mags[b]!.compareTo(mags[a]!))).take(6).toSet() : out;
}
