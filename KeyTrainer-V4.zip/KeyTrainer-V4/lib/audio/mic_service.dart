import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:record/record.dart';
import '../midi/midi_service.dart';
import '../music/theory.dart';
import 'pitch.dart';

/// Análise de áudio pelo microfone do aparelho. Converte o que ouve em notas
/// e injeta no mesmo fluxo do MIDI (MidiService), então o treino funciona igual.
class MicService extends ChangeNotifier {
  MicService(this.midi);
  final MidiService midi;
  final _rec = AudioRecorder();
  static const sr = 44100;

  bool listening = false, chordMode = false;
  double sensitivity = 0.012; // RMS mínimo para considerar que há som
  double level = 0;
  String status = 'Microfone desligado';
  Set<int> active = {};
  String? chord;
  StreamSubscription<Uint8List>? _sub;
  final List<double> _buf = [];
  Set<int> _cand = {};
  int _stable = 0;
  double _prevRms = 0;

  int get _win => chordMode ? 16384 : 2048;
  int get _hop => chordMode ? 4096 : 2048;

  Future<void> start() async {
    if (listening) return;
    if (!await _rec.hasPermission()) {
      status = 'Permissão do microfone negada';
      notifyListeners();
      return;
    }
    final stream = await _rec.startStream(const RecordConfig(
      encoder: AudioEncoder.pcm16bits, sampleRate: sr, numChannels: 1,
      echoCancel: false, noiseSuppress: false, autoGain: false));
    _sub = stream.listen(_onData);
    listening = true;
    status = 'Ouvindo…';
    notifyListeners();
  }

  Future<void> stop() async {
    await _sub?.cancel();
    if (listening) await _rec.stop();
    for (final n in active) { midi.release(n); }
    active = {};
    listening = false;
    level = 0;
    chord = null;
    _buf.clear();
    status = 'Microfone desligado';
    notifyListeners();
  }

  void setChordMode(bool v) { chordMode = v; _buf.clear(); notifyListeners(); }
  void setSensitivity(double v) { sensitivity = v; notifyListeners(); }

  void _onData(Uint8List bytes) {
    final bd = ByteData.sublistView(bytes);
    for (var i = 0; i + 1 < bytes.length; i += 2) {
      _buf.add(bd.getInt16(i, Endian.little) / 32768.0);
    }
    while (_buf.length >= _win) {
      _analyze(Float64List.fromList(_buf.sublist(0, _win)));
      _buf.removeRange(0, _hop);
    }
  }

  void _analyze(Float64List f) {
    var e = 0.0;
    for (final v in f) { e += v * v; }
    final rms = sqrt(e / f.length);
    level = rms;
    Set<int> notes = {};
    if (rms >= sensitivity) {
      if (chordMode) {
        notes = multiPitch(f, sr);
      } else {
        final hz = yinPitch(f, sr);
        if (hz != null) {
          final m = freqToMidi(hz);
          if (m >= 36 && m <= 96) notes = {m};
        }
      }
    }
    // exige 2 análises iguais seguidas (evita notas "fantasma")
    final same = setEquals(notes, _cand);
    _stable = same ? _stable + 1 : 1;
    _cand = notes;
    final attack = rms > _prevRms * 1.8 && rms >= sensitivity;
    _prevRms = rms;
    if (_stable >= 2 || notes.isEmpty) {
      if (!setEquals(notes, active)) {
        for (final n in active.difference(notes)) { midi.release(n); }
        for (final n in notes.difference(active)) { midi.press(n, external: true); }
        active = notes;
      } else if (attack && notes.isNotEmpty) {
        // mesma nota tocada de novo
        for (final n in notes) { midi.release(n); midi.press(n, external: true); }
      }
    }
    chord = chordMode && active.length >= 3 ? detectChord(active) : null;
    status = active.isEmpty ? 'Ouvindo…' : 'Ouvindo: ${(active.toList()..sort()).map(noteName).join(' ')}';
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _rec.dispose();
    super.dispose();
  }
}
