import 'dart:math';
import '../core/models.dart';
import '../music/theory.dart';
import '../progress/store.dart';

class PlanItem {
  final String title, desc;
  final Exercise exercise;
  final int bpm;
  PlanItem(this.title, this.desc, this.exercise, this.bpm);
}

/// Professor local baseado em regras (sem internet, sem LLM).
class Teacher {
  /// Notas esperadas com mais erros nas últimas sessões.
  static List<MapEntry<int, int>> weakNotes(AppStore s, {int last = 20}) {
    final c = <int, int>{};
    for (final r in s.sessions.reversed.take(last)) {
      r.errs.forEach((k, v) {
        final m = int.parse(k.split('>')[0]);
        c[m] = (c[m] ?? 0) + v;
      });
    }
    final l = c.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return l.take(5).toList();
  }

  /// Gera exercício a partir dos erros: cada nota fraca entre vizinhas.
  static Exercise? fromErrors(AppStore s) {
    final w = weakNotes(s);
    if (w.isEmpty) return null;
    Step st(int n) => Step(noteName(n),
        right: n >= 60 ? [n] : const [], left: n < 60 ? [n] : const []);
    final steps = <Step>[];
    for (final e in w.take(4)) {
      final m = e.key;
      for (final n in [m, m + 2, m, m + 4, m]) {
        steps.add(st(min(n, 96)));
      }
    }
    return Exercise('gen-${DateTime.now().millisecondsSinceEpoch}', 'Reforço: suas notas fracas',
        'Gerado', max(40, s.defaultBpm - 15), steps, user: true);
  }

  static int suggestBpm(AppStore s, String id, int base) {
    final l = s.sessions.where((x) => x.exerciseId == id).toList();
    if (l.isEmpty) return (base * 0.8).round().clamp(40, 200);
    final last = l.takeLast(3);
    final acc = last.map((x) => x.accuracy).reduce((a, b) => a + b) / last.length;
    final b = l.last.bpm;
    if (acc >= 0.9) return (b + 6).clamp(40, 200);
    if (acc < 0.7) return (b - 8).clamp(40, 200);
    return b;
  }

  static List<String> explain(SessionResult r) {
    final out = <String>[];
    final es = r.errs.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    for (final e in es.take(3)) {
      final p = e.key.split('>');
      final exp = int.parse(p[0]), got = int.parse(p[1]), n = e.value;
      if (got < 0) {
        out.add('${noteName(exp)} não foi tocada a tempo ($n×). Reduza o BPM ou use "esperar nota".');
      } else {
        final d = (got - exp).abs();
        if (d % 12 == 0) {
          out.add('Você tocou ${noteName(got)} em vez de ${noteName(exp)} ($n×): oitava errada.');
        } else if (d <= 2) {
          out.add('Você tocou ${noteName(got)} em vez de ${noteName(exp)} ($n×): tecla vizinha. Revise a posição da mão.');
        } else {
          out.add('Você tocou ${noteName(got)} em vez de ${noteName(exp)} ($n×): salto de $d semitons. Treine esse intervalo isolado.');
        }
      }
    }
    final beat = 60000 / r.bpm;
    if (r.avgLateMs > beat * 0.4) out.add('Você tende a atrasar (média ${r.avgLateMs.round()} ms). Treine com metrônomo mais lento.');
    if (out.isEmpty) out.add('Sem erros relevantes. Bom trabalho!');
    return out;
  }

  static List<String> recommendations(AppStore s) {
    if (s.sessions.isEmpty) return ['Comece por "Escala de Dó - mão direita" no modo "esperar nota".'];
    final out = <String>[];
    final last = s.sessions.takeLast(3);
    final acc = last.map((x) => x.accuracy).reduce((a, b) => a + b) / last.length;
    if (acc >= 0.9) out.add('Precisão alta (${(acc * 100).round()}%): suba o BPM em 5–8 ou passe para duas mãos.');
    if (acc < 0.7) out.add('Precisão em ${(acc * 100).round()}%: use o modo lento (50%) e o modo "esperar nota".');
    final w = weakNotes(s);
    if (w.isNotEmpty) out.add('Notas mais difíceis: ${w.map((e) => noteName(e.key)).join(', ')}. Há um exercício de reforço no plano de hoje.');
    if (s.streak == 0) out.add('Você ainda não treinou hoje. Uma sessão curta já mantém o ritmo.');
    return out.isEmpty ? ['Continue assim: regularidade vale mais que sessões longas.'] : out;
  }

  static List<PlanItem> dailyPlan(AppStore s) {
    final all = s.all;
    if (all.isEmpty) return [];
    final plan = <PlanItem>[];
    final warm = all.firstWhere((e) => e.level == 'Iniciante', orElse: () => all.first);
    plan.add(PlanItem('Aquecimento', warm.title, warm, suggestBpm(s, warm.id, warm.bpm)));
    final g = fromErrors(s);
    if (g != null) plan.add(PlanItem('Reforço dos erros', 'Notas fracas em contexto', g, g.bpm));
    final counts = {for (final e in all) e.id: s.sessions.where((x) => x.exerciseId == e.id).length};
    final least = all.reduce((a, b) => counts[a.id]! <= counts[b.id]! ? a : b);
    plan.add(PlanItem('Novidade', least.title, least, suggestBpm(s, least.id, least.bpm)));
    return plan;
  }

  static String analyze(Exercise e) {
    final all = e.steps.expand((s) => [...s.left, ...s.right]).toList();
    if (all.isEmpty) return 'Exercício vazio.';
    var leaps = 0;
    int? prev;
    for (final s in e.steps) {
      final cur = s.right.isNotEmpty ? s.right.first : (s.left.isNotEmpty ? s.left.first : null);
      if (cur != null && prev != null && (cur - prev).abs() > 7) leaps++;
      if (cur != null) prev = cur;
    }
    final chords = e.steps.where((s) => s.right.length + s.left.length > 2).length;
    final both = e.steps.any((s) => s.left.isNotEmpty && s.right.isNotEmpty);
    final d = 1 + (both ? 1 : 0) + (leaps > 3 ? 1 : 0) + (chords > 4 ? 1 : 0) + (e.bpm > 100 ? 1 : 0);
    return 'Extensão: ${noteName(all.reduce(min))} a ${noteName(all.reduce(max))}\n'
        'Passos: ${e.steps.length} · Acordes: $chords · Saltos grandes: $leaps\n'
        'Mãos: ${both ? "coordenação das duas" : "uma por vez"}\n'
        'Dificuldade estimada: $d/5';
  }
}

extension _Last<T> on List<T> {
  List<T> takeLast(int n) => length <= n ? this : sublist(length - n);
}
