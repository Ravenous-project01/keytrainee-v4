import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/models.dart';

/// Estado do app + persistência local (exercícios do usuário, histórico, metas).
class AppStore extends ChangeNotifier {
  int tab = 0;
  Exercise? selected;
  int? selectedBpm;
  List<Exercise> builtin = [], user = [];
  List<SessionResult> sessions = [];
  int defaultBpm = 80, dailyGoal = 3;
  late SharedPreferences _p;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final raw = await rootBundle.loadString('assets/exercises/exercises.json');
    builtin = (jsonDecode(raw) as List).map((e) => Exercise.fromJson(e)).toList();
    user = (jsonDecode(_p.getString('user') ?? '[]') as List).map((e) => Exercise.fromJson(e, user: true)).toList();
    sessions = (jsonDecode(_p.getString('sessions') ?? '[]') as List).map((e) => SessionResult.fromJson(e)).toList();
    defaultBpm = _p.getInt('bpm') ?? 80;
    dailyGoal = _p.getInt('goal') ?? 3;
  }

  List<Exercise> get all => [...user, ...builtin];

  void go(int t) { tab = t; notifyListeners(); }
  void select(Exercise e, {int? bpm}) {
    selected = e;
    selectedBpm = bpm;
    tab = 2;
    notifyListeners();
  }

  Future<void> addUser(Exercise e) async {
    user.insert(0, e);
    await _p.setString('user', jsonEncode(user.map((x) => x.toJson()).toList()));
    notifyListeners();
  }

  Future<void> removeUser(String id) async {
    user.removeWhere((e) => e.id == id);
    await _p.setString('user', jsonEncode(user.map((x) => x.toJson()).toList()));
    notifyListeners();
  }

  Future<void> addSession(SessionResult r) async {
    sessions.add(r);
    if (sessions.length > 300) sessions.removeAt(0);
    await _p.setString('sessions', jsonEncode(sessions.map((x) => x.toJson()).toList()));
    notifyListeners();
  }

  Future<void> setGoal(int g) async { dailyGoal = g; await _p.setInt('goal', g); notifyListeners(); }
  Future<void> setDefaultBpm(int b) async { defaultBpm = b; await _p.setInt('bpm', b); notifyListeners(); }

  static bool _same(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;
  int get todayCount => sessions.where((s) => _same(s.date, DateTime.now())).length;
  int get xp => sessions.fold(0, (a, s) => a + s.hits * 2 + (s.accuracy >= 0.9 ? 20 : 0));
  int get level => 1 + xp ~/ 400;

  int get streak {
    var d = DateTime.now();
    if (!sessions.any((s) => _same(s.date, d))) d = d.subtract(const Duration(days: 1));
    var n = 0;
    while (sessions.any((s) => _same(s.date, d))) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  List<String> get achievements => [
        if (sessions.isNotEmpty) '🎯 Primeira sessão',
        if (sessions.length >= 10) '🔟 10 sessões',
        if (sessions.any((s) => s.accuracy >= 0.9 && s.hits >= 8)) '⭐ Precisão acima de 90%',
        if (streak >= 3) '🔥 3 dias seguidos',
        if (level >= 5) '🏆 Nível 5',
        if (user.isNotEmpty) '📄 Importou uma cifra',
      ];
}
