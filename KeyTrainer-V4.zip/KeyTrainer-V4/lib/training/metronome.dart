import 'dart:async';
import 'package:flutter/foundation.dart';
import '../audio/synth.dart';

class Metronome extends ChangeNotifier {
  int bpm = 80, beatsPerBar = 4, beat = 0;
  bool running = false;
  Timer? _t;

  void start() {
    _t?.cancel();
    running = true;
    beat = 0;
    _tick();
    _t = Timer.periodic(Duration(milliseconds: (60000 / bpm).round()), (_) => _tick());
    notifyListeners();
  }

  void _tick() {
    Synth.click(beat % beatsPerBar == 0);
    beat++;
    notifyListeners();
  }

  void stop() {
    _t?.cancel();
    running = false;
    notifyListeners();
  }

  void setBpm(int b) {
    bpm = b;
    if (running) start(); else notifyListeners();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }
}
