import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import '../core/models.dart';
import '../midi/midi_service.dart';

enum Mode { wait, timed }
enum Hand { right, left, both }

/// Motor de treino: compara nota a nota (e acordes) com o exercício.
class TrainingEngine extends ChangeNotifier {
  TrainingEngine(this.midi) {
    _sub = midi.onNoteOn.listen(_onNote);
  }
  final MidiService midi;
  late final StreamSubscription<int> _sub;

  Exercise? ex;
  Mode mode = Mode.wait;
  Hand hand = Hand.both;
  int bpm = 80;
  double speed = 1; // 0.5 = modo lento
  bool loop = false;
  int loopFrom = 1, loopTo = 1;
  bool running = false;
  bool octaveFree = false; // microfone: compara só a classe da nota (oitava livre)
  int index = 0, loops = 0, hits = 0, errors = 0, misses = 0;
  final Set<int> hit = {}, wrong = {};
  final Map<String, int> errs = {};
  final List<int> lates = [];
  String? info;
  SessionResult? result;
  bool _done = false;
  Timer? _timer;
  DateTime _t0 = DateTime.now(), _stepStart = DateTime.now();

  List<int> _req(Step s) => switch (hand) {
        Hand.right => s.right,
        Hand.left => s.left,
        Hand.both => [...s.left, ...s.right],
      };
  List<int> get required =>
      ex == null || index < 0 || index >= ex!.steps.length ? [] : _req(ex!.steps[index]);
  String get label => ex == null || index < 0 || index >= ex!.steps.length ? '' : ex!.steps[index].label;
  int get totalBars => ex == null ? 1 : max(1, (ex!.steps.fold(0.0, (a, s) => a + s.beats) / 4).ceil());
  double get progress => ex == null || ex!.steps.isEmpty ? 0 : (index.clamp(0, ex!.steps.length)) / ex!.steps.length;
  int get _stepMs => (ex!.steps[index].beats * 60000 / (bpm * speed)).round();

  int _bar(int stepIdx) {
    var b = 0.0;
    for (var i = 0; i < stepIdx; i++) {
      b += ex!.steps[i].beats;
    }
    return b ~/ 4 + 1;
  }

  (int, int) get _range {
    final n = ex!.steps.length;
    if (!loop) return (0, n - 1);
    var a = -1, b = n - 1;
    for (var i = 0; i < n; i++) {
      final bar = _bar(i);
      if (bar >= loopFrom && a < 0) a = i;
      if (bar <= loopTo) b = i;
    }
    return (a < 0 ? 0 : a, max(a < 0 ? 0 : a, b));
  }

  void load(Exercise e, int b) {
    stop(silent: true);
    ex = e;
    bpm = b;
    index = 0;
    loopFrom = 1;
    loopTo = totalBars;
    hit.clear();
    wrong.clear();
    info = null;
    notifyListeners();
  }

  void setMode(Mode m) { mode = m; notifyListeners(); }
  void setHand(Hand h) { hand = h; notifyListeners(); }
  void setBpm(int b) { bpm = b; notifyListeners(); }
  void setSpeed(double s) { speed = s; notifyListeners(); }
  void setLoop(bool v) { loop = v; notifyListeners(); }
  void setLoopRange(int a, int b) { loopFrom = a; loopTo = max(a, b); notifyListeners(); }

  void start() {
    if (ex == null) return;
    if (!ex!.steps.any((s) => _req(s).isNotEmpty)) {
      info = 'Este exercício não tem notas para a mão escolhida.';
      notifyListeners();
      return;
    }
    info = null;
    hits = errors = misses = loops = 0;
    errs.clear();
    lates.clear();
    result = null;
    running = true;
    _t0 = DateTime.now();
    index = _range.$1 - 1;
    _advance();
  }

  void stop({bool silent = false}) {
    _timer?.cancel();
    if (running) {
      if (silent) {
        running = false;
      } else {
        _finish();
        return;
      }
    }
    notifyListeners();
  }

  void _advance() {
    final r = _range;
    do {
      index++;
      if (index > r.$2) {
        if (loop) {
          loops++;
          index = r.$1;
        } else {
          _finish();
          return;
        }
      }
    } while (required.isEmpty);
    hit.clear();
    wrong.clear();
    _done = false;
    _stepStart = DateTime.now();
    _timer?.cancel();
    if (mode == Mode.timed) _timer = Timer(Duration(milliseconds: _stepMs), _timeout);
    notifyListeners();
  }

  void _timeout() {
    if (!running) return;
    if (!_done) {
      misses++;
      for (final m in required.where((m) => !hit.contains(m))) {
        errs['$m>-1'] = (errs['$m>-1'] ?? 0) + 1;
      }
    }
    _advance();
  }

  void _onNote(int raw) {
    if (!running || _done) return;
    final req = required;
    var n = raw;
    if (octaveFree) {
      final m = req.where((r) => r % 12 == raw % 12).toList();
      if (m.isNotEmpty) n = m.firstWhere((r) => !hit.contains(r), orElse: () => m.first);
    }
    if (req.contains(n)) {
      hit.add(n);
      if (hit.containsAll(req)) {
        hits++;
        _done = true;
        lates.add(DateTime.now().difference(_stepStart).inMilliseconds);
        if (mode == Mode.wait) {
          _timer?.cancel();
          _timer = Timer(const Duration(milliseconds: 120), _advance);
        }
      }
    } else {
      errors++;
      wrong.add(n);
      final exp = req.firstWhere((m) => !hit.contains(m), orElse: () => req.first);
      errs['$exp>$n'] = (errs['$exp>$n'] ?? 0) + 1;
    }
    notifyListeners();
  }

  void _finish() {
    _timer?.cancel();
    running = false;
    if (hits + errors + misses > 0 && ex != null) {
      result = SessionResult(
        exerciseId: ex!.id, title: ex!.title, date: DateTime.now(),
        bpm: (bpm * speed).round(), hits: hits, errors: errors, misses: misses,
        seconds: DateTime.now().difference(_t0).inSeconds,
        avgLateMs: mode == Mode.timed && lates.isNotEmpty ? lates.reduce((a, b) => a + b) / lates.length : 0,
        errs: Map.of(errs));
    }
    notifyListeners();
  }

  @override
  void dispose() {
    _sub.cancel();
    _timer?.cancel();
    super.dispose();
  }
}
