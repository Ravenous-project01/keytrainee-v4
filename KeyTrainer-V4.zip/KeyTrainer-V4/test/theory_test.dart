import 'dart:math';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:keytrainer/audio/pitch.dart';
import 'package:keytrainer/music/theory.dart';

Float64List tone(double f, int n, int sr) =>
    Float64List.fromList([for (var i = 0; i < n; i++) 0.5 * sin(2 * pi * f * i / sr)]);

void main() {
  test('detecta acordes', () {
    expect(detectChord([60, 64, 67]), 'C');
    expect(detectChord([57, 60, 64]), 'Am');
    expect(detectChord([64, 67, 72]), 'C/E');
    expect(detectChord([62, 65, 69, 72]), 'Dm7');
  });
  test('extrai cifras só de linhas de cifra', () {
    expect(extractChords('Intro\nC G Am F\nUma letra qualquer'), ['C', 'G', 'Am', 'F']);
  });
  test('cifra vira passo', () {
    expect(chordStep('Am')!.right, [69, 72, 76]);
    expect(chordStep('X'), isNull);
  });
  test('YIN acha o Lá 440 Hz', () {
    final hz = yinPitch(tone(440, 2048, 44100), 44100)!;
    expect(freqToMidi(hz), 69);
  });
  test('YIN acha o Dó central', () {
    expect(freqToMidi(yinPitch(tone(261.63, 2048, 44100), 44100)!), 60);
  });
  test('multi-pitch acha tríade de Dó', () {
    const sr = 44100, n = 16384;
    final x = Float64List.fromList([
      for (var i = 0; i < n; i++)
        0.2 * (sin(2 * pi * 261.63 * i / sr) + sin(2 * pi * 329.63 * i / sr) + sin(2 * pi * 392.0 * i / sr))
    ]);
    expect(multiPitch(x, sr).map((m) => m % 12).toSet(), {0, 4, 7});
  });
}
