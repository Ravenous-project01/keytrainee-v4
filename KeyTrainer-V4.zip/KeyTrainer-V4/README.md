# KeyTrainer V4

App Android (Flutter) para treinar teclado/piano: teclado virtual, metrônomo, exercícios, MIDI USB/Bluetooth,
**análise de áudio pelo microfone**, PDF + OCR de cifras, professor local e evolução.

## Como gerar o APK (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta.
2. Aba **Actions → Build APK → Run workflow**.
3. Baixe o artefato `keytrainer-apk` e instale no celular (permita "fontes desconhecidas").

## Compilar localmente
```
flutter create --platforms=android --org com.keytrainer --project-name keytrainer .
bash tool/patch_android.sh      # permissões (MIDI, Bluetooth, microfone) + minSdk 24
flutter pub get && flutter test && flutter build apk --release
```

## Arquitetura (lib/)
- `core/` modelos (Exercise, Step, SessionResult)
- `music/` teoria: acordes, cifras → passos, extração de cifras
- `midi/` USB/BLE MIDI + entrada de notas unificada (teclado virtual, MIDI e microfone)
- `audio/` sintetizador, **pitch.dart (YIN + multi-pitch)**, **mic_service.dart**
- `training/` motor (esperar nota, no tempo, mãos, loop, lento, pontuação) e metrônomo
- `pdf/` visualização e OCR (ML Kit, no aparelho)
- `ai/` professor local por regras: pontos fracos, plano diário, BPM, exercício dos erros
- `progress/` persistência, XP, nível, metas, conquistas
- `ui/` telas

## Microfone: como funciona e limites
O microfone alimenta o mesmo fluxo de notas do MIDI, então todo o treino funciona igual.
- **Nota única:** YIN (rápido, bom para melodias/escalas).
- **Acordes (beta):** análise espectral por nota MIDI; janela longa (~0,4 s de atraso) e menos precisa.
- Com o microfone ligado, a comparação ignora a oitava (conta só a nota) e o som do app é desligado
  para não "ouvir a si mesmo". Ambiente silencioso e metrônomo em fones ajudam muito.

## Limites honestos
- Código **não foi compilado nem testado em aparelho** por quem o escreveu (sem Flutter aqui). Versões de pacotes podem exigir ajuste de `pubspec.yaml`.
- Partitura: o PDF é exibido, mas o app **não lê notação musical**; o OCR reconhece **cifras** (letras de acordes). Sempre confira o texto lido.
- "IA" = professor por regras, local, sem internet. Não usa LLM.
- Sincronização PDF↔treino: abre a página do PDF do exercício; não destaca o acorde na página.
- Áudio do app tem latência perceptível; para tocar de verdade use o som do teclado.
