#!/usr/bin/env bash
# Ajusta o projeto Android gerado por `flutter create`: permissões MIDI/Bluetooth e minSdk.
set -e
rm -f test/widget_test.dart
M=android/app/src/main/AndroidManifest.xml
PERMS='<uses-permission android:name="android.permission.RECORD_AUDIO"/><uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/><uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/><uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation"/><uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/><uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/><uses-feature android:name="android.hardware.usb.host" android:required="false"/><uses-feature android:name="android.software.midi" android:required="false"/>'
sed -i "s#<application#${PERMS}<application#" "$M"
for f in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$f" ] && sed -i 's/minSdk = flutter.minSdkVersion/minSdk = 24/; s/minSdkVersion flutter.minSdkVersion/minSdkVersion 24/' "$f" || true
done
echo "Android ajustado."
